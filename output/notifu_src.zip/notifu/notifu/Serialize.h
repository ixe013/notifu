#pragma once

void SerializeEnter();
bool ThreadWaiting();
void SerializeLeave();
