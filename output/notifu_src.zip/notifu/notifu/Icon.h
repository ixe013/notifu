// Icon.h: interface for the Icon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ICON_H__DB8300D2_CA37_41D7_BBC3_EBD6B8FB0726__INCLUDED_)
#define AFX_ICON_H__DB8300D2_CA37_41D7_BBC3_EBD6B8FB0726__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

HICON GoFindAnIcon(LPCTSTR path);

#endif // !defined(AFX_ICON_H__DB8300D2_CA37_41D7_BBC3_EBD6B8FB0726__INCLUDED_)
