#pragma once

#include "NOTIFU_PARAM.h"

HRESULT NotifyUser(const NOTIFU_PARAM& params);
