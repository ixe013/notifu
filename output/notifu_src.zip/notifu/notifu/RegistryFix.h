#pragma once

LONG EnableBalloonTips(bool=true);